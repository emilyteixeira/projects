public class Automovel{
    protected String nome;
    protected String fabricante;

    public void setNome(String varnome){
        nome = varnome;
    }

    public String getNome(){
        return nome;
    }

    public void setFabricante(String varfabricante){
        fabricante = varfabricante;
    }

    public String getFabricante(){
        return fabricante;
    }
}