public class Moto extends Automovel{
    private String cor;
    private String modelo;

    public void setCor(String varcor){
        cor = varcor;
    }

    public String getCor(){
        return cor;
    }

    public void setModelo(String varmodelo){
        modelo = varmodelo;
    }

    public String getModelo(){
        return modelo;
    }
}
